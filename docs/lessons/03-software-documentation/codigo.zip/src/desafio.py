def desafio1(n):
    #return 0
    return n
